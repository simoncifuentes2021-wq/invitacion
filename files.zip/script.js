/**
 * Alex & Trayssi — Invitación Digital de Matrimonio
 * Script principal: apertura, pétalos, animaciones de scroll
 */

'use strict';

/* ══════════════════════════════════════════════════
   PÉTALOS / PARTÍCULAS — Canvas compartido
   ══════════════════════════════════════════════════ */

class Petal {
  constructor(canvas, isOpening = false) {
    this.canvas = canvas;
    this.isOpening = isOpening;
    this.reset(true);
  }

  reset(initial = false) {
    const w = this.canvas.width;
    const h = this.canvas.height;
    this.x = Math.random() * w;
    this.y = initial ? Math.random() * h : -20;
    this.size = Math.random() * 8 + 4;
    this.speedY = Math.random() * 1.2 + 0.4;
    this.speedX = (Math.random() - 0.5) * 0.8;
    this.rotation = Math.random() * Math.PI * 2;
    this.rotSpeed = (Math.random() - 0.5) * 0.03;
    this.opacity = Math.random() * 0.5 + 0.15;
    this.swing = Math.random() * Math.PI * 2;
    this.swingSpeed = Math.random() * 0.02 + 0.01;
    this.swingAmp = Math.random() * 20 + 8;
    // Variantes de color: burdeos y dorado
    const colors = ['#8B1A2F', '#A52035', '#C02840', '#7A1528', '#C9A84C', '#E2C97E'];
    this.color = colors[Math.floor(Math.random() * colors.length)];
  }

  update() {
    this.y += this.speedY;
    this.swing += this.swingSpeed;
    this.x += Math.sin(this.swing) * 0.6 + this.speedX;
    this.rotation += this.rotSpeed;
    if (this.y > this.canvas.height + 20) this.reset();
  }

  draw(ctx) {
    ctx.save();
    ctx.globalAlpha = this.opacity;
    ctx.translate(this.x, this.y);
    ctx.rotate(this.rotation);
    ctx.fillStyle = this.color;

    // Forma de pétalo simple
    ctx.beginPath();
    ctx.ellipse(0, 0, this.size * 0.45, this.size, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

/* ── Pétalos en pantalla de apertura ── */
(function initOpeningPetals() {
  const canvas = document.getElementById('opening-petals');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let petals = [];
  let raf;

  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  }

  function init() {
    resize();
    petals = Array.from({ length: 30 }, () => new Petal(canvas, true));
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    petals.forEach(p => { p.update(); p.draw(ctx); });
    raf = requestAnimationFrame(animate);
  }

  window.addEventListener('resize', resize);
  init();
  animate();

  // Exponer función para detener al cerrar
  window._stopOpeningPetals = () => {
    cancelAnimationFrame(raf);
  };
})();

/* ── Pétalos en contenido principal ── */
(function initMainPetals() {
  const canvas = document.getElementById('petals-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let petals = [];
  let raf;
  let running = false;

  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  }

  function init() {
    resize();
    // Menos pétalos en main para no distraer
    petals = Array.from({ length: 18 }, () => new Petal(canvas, true));
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    petals.forEach(p => { p.update(); p.draw(ctx); });
    raf = requestAnimationFrame(animate);
  }

  window.addEventListener('resize', resize);
  init();

  // Se activa cuando el main es visible
  window._startMainPetals = () => {
    if (!running) { running = true; animate(); }
  };
})();


/* ══════════════════════════════════════════════════
   APERTURA DEL SOBRE
   ══════════════════════════════════════════════════ */
(function initOpening() {
  const openBtn      = document.getElementById('openBtn');
  const openScreen   = document.getElementById('opening-screen');
  const mainContent  = document.getElementById('main-content');

  if (!openBtn || !openScreen || !mainContent) return;

  function openInvitation() {
    // Efecto de apertura: fade-out de la pantalla de apertura
    openScreen.classList.add('fade-out');

    // Preparar contenido principal
    mainContent.classList.remove('hidden');
    mainContent.style.opacity = '0';

    setTimeout(() => {
      // Activar pétalos del main
      if (window._startMainPetals) window._startMainPetals();

      // Aparecer contenido con fade
      mainContent.style.transition = 'opacity 0.8s ease';
      mainContent.style.opacity = '1';

      // Scroll al inicio y activar animaciones del hero
      window.scrollTo({ top: 0 });

      setTimeout(() => {
        openScreen.style.display = 'none';
        if (window._stopOpeningPetals) window._stopOpeningPetals();

        // Activar fade-in del hero
        triggerHeroAnimations();
        // Iniciar observer de scroll
        initScrollObserver();
      }, 600);

    }, 700);
  }

  openBtn.addEventListener('click', openInvitation);
  openBtn.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') openInvitation();
  });
  openBtn.setAttribute('tabindex', '0');
  openBtn.setAttribute('role', 'button');
  openBtn.setAttribute('aria-label', 'Abrir invitación');
})();


/* ══════════════════════════════════════════════════
   ANIMACIONES HERO — aparición progresiva
   ══════════════════════════════════════════════════ */
function triggerHeroAnimations() {
  const elements = document.querySelectorAll('.hero-section .fade-in-up');
  elements.forEach(el => {
    const delay = parseFloat(getComputedStyle(el).transitionDelay) || 0;
    setTimeout(() => el.classList.add('visible'), delay * 1000 + 100);
  });
}


/* ══════════════════════════════════════════════════
   SCROLL OBSERVER — revelar secciones
   ══════════════════════════════════════════════════ */
function initScrollObserver() {
  const revealSections = document.querySelectorAll('.reveal-section');
  const revealCards    = document.querySelectorAll('.reveal-card');

  const opts = {
    root: null,
    rootMargin: '0px 0px -80px 0px',
    threshold: 0.15
  };

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        sectionObserver.unobserve(entry.target);
      }
    });
  }, opts);

  const cardOpts = { ...opts, threshold: 0.1 };

  const cardObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        // Delay escalonado para múltiples cards
        setTimeout(() => entry.target.classList.add('visible'), i * 120);
        cardObserver.unobserve(entry.target);
      }
    });
  }, cardOpts);

  revealSections.forEach(el => sectionObserver.observe(el));
  revealCards.forEach(el => cardObserver.observe(el));
}


/* ══════════════════════════════════════════════════
   PARALLAX SUTIL en flores del hero
   ══════════════════════════════════════════════════ */
(function initParallax() {
  const floralTop    = document.querySelector('.floral-top');
  const floralBottom = document.querySelector('.floral-bottom');

  if (!floralTop || !floralBottom) return;

  let ticking = false;

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        // Flores superiores se mueven hacia arriba suavemente
        floralTop.style.transform    = `translateY(${scrollY * 0.18}px)`;
        // Flores inferiores se mueven hacia abajo suavemente
        floralBottom.style.transform = `translateY(${scrollY * -0.12}px)`;
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
})();


/* ══════════════════════════════════════════════════
   MICROINTERACCIÓN: brillos en los nombres del hero
   ══════════════════════════════════════════════════ */
(function initNameShimmer() {
  const names = document.querySelectorAll('.name-script');
  names.forEach(name => {
    name.addEventListener('mouseenter', () => {
      name.style.textShadow = '0 2px 30px rgba(139,26,47,0.25), 0 0 60px rgba(201,168,76,0.15)';
    });
    name.addEventListener('mouseleave', () => {
      name.style.textShadow = '0 2px 20px rgba(139,26,47,0.12)';
    });
  });
})();


/* ══════════════════════════════════════════════════
   COPIADO AL PORTAPAPELES — datos bancarios
   ══════════════════════════════════════════════════ */
(function initCopyGifts() {
  const giftValues = document.querySelectorAll('.gift-value');

  giftValues.forEach(el => {
    el.style.cursor = 'pointer';
    el.setAttribute('title', 'Clic para copiar');

    el.addEventListener('click', () => {
      const text = el.textContent.trim();
      if (!navigator.clipboard) return;

      navigator.clipboard.writeText(text).then(() => {
        const original = el.textContent;
        el.textContent = '✓ Copiado';
        el.style.color = '#4A6741';
        setTimeout(() => {
          el.textContent = original;
          el.style.color = '';
        }, 1500);
      }).catch(() => {});
    });
  });
})();


/* ══════════════════════════════════════════════════
   COUNTER ANIMADO — cuenta regresiva hasta el 14 Nov
   ══════════════════════════════════════════════════ */
(function initCountdown() {
  // La boda es 14 de Noviembre 2026 a las 11:30
  const weddingDate = new Date('2026-11-14T11:30:00');

  function getCountdown() {
    const now  = new Date();
    const diff = weddingDate - now;
    if (diff <= 0) return null;

    const days    = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours   = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return { days, hours, minutes };
  }

  // Insertar el countdown discretamente en el hero, bajo la fecha
  const dateBlock = document.querySelector('.date-block');
  if (!dateBlock) return;

  const cd = getCountdown();
  if (!cd) return; // Ya pasó la fecha

  const cdEl = document.createElement('div');
  cdEl.className = 'countdown-widget fade-in-up';
  cdEl.style.cssText = `
    display: flex; gap: 1.5rem; align-items: center; justify-content: center;
    opacity: 0; transform: translateY(20px); transition: opacity 0.9s ease 1.1s, transform 0.9s ease 1.1s;
    margin-top: 0.2rem;
  `;

  function renderCd(data) {
    return `
      <div style="text-align:center;">
        <div style="font-family:'Cinzel',serif; font-size:1.4rem; font-weight:500; color:#8B1A2F; line-height:1;">${data.days}</div>
        <div style="font-family:'Cinzel',serif; font-size:0.55rem; letter-spacing:0.15em; text-transform:uppercase; color:#8B6070; margin-top:0.25rem;">días</div>
      </div>
      <div style="color:#C9A84C; opacity:0.4; font-size:1rem;">·</div>
      <div style="text-align:center;">
        <div style="font-family:'Cinzel',serif; font-size:1.4rem; font-weight:500; color:#8B1A2F; line-height:1;">${String(data.hours).padStart(2,'0')}</div>
        <div style="font-family:'Cinzel',serif; font-size:0.55rem; letter-spacing:0.15em; text-transform:uppercase; color:#8B6070; margin-top:0.25rem;">hrs</div>
      </div>
      <div style="color:#C9A84C; opacity:0.4; font-size:1rem;">·</div>
      <div style="text-align:center;">
        <div style="font-family:'Cinzel',serif; font-size:1.4rem; font-weight:500; color:#8B1A2F; line-height:1;">${String(data.minutes).padStart(2,'0')}</div>
        <div style="font-family:'Cinzel',serif; font-size:0.55rem; letter-spacing:0.15em; text-transform:uppercase; color:#8B6070; margin-top:0.25rem;">min</div>
      </div>
    `;
  }

  cdEl.innerHTML = renderCd(cd);
  dateBlock.insertAdjacentElement('afterend', cdEl);

  // Activar visibilidad (se activa cuando hero anima)
  setTimeout(() => {
    cdEl.style.opacity = '1';
    cdEl.style.transform = 'translateY(0)';
  }, 1300);

  // Actualizar cada minuto
  setInterval(() => {
    const data = getCountdown();
    if (data) cdEl.innerHTML = renderCd(data);
  }, 60000);
})();
